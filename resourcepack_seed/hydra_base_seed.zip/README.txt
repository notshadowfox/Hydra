Hydra base pack. Add files gradually.
Economy hotbar icon:
- Item: minecraft:gold_nugget
- CustomModelData: 9101
- Model: hydra:item/ui/coin_shop
